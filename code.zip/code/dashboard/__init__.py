"""
GhostTrace AI Dashboard Package
"""
